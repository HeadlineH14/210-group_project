javac *.java && java Drawing
